const mysql = require('mysql2');
const querystring = require('querystring');

exports.handler = function(event, context, callback) {

    if (event.body !== null && event.body !== undefined) {

        var bodyBase64 = Buffer.from(event.body, 'base64').toString();
        var body = querystring.parse(bodyBase64);

        var shipperid = body.shipperid;
        var company = body.company;
        var phone = body.phone;

        var conn = mysql.createConnection({
            host: "database-1.cwaflgqidzea.us-east-1.rds.amazonaws.com",
            user: "admin",
            password: "a5yL98uj0EVok9KraXkP",
            port: 3306,
            database: "northwind"
        });

        conn.connect(function(error) {
            if (error) {
                conn.end(function() {
                    callback(error, {
                        statusCode: 400,
                        body: JSON.stringify({
                            "estado": "error",
                            "msg": "error en la conexión a base de datos"
                        })
                    });
                });
            }
            else {

                var sql = "INSERT INTO `northwind`.`shippers` (`ShipperID`, `CompanyName`, `Phone`) VALUES (?, ?, ?);";

                conn.query(sql, [shipperid, company, phone], function(error, result) {
                    if (error) {
                        conn.end(function() {
                            callback(error, {
                                statusCode: 400,
                                body: JSON.stringify({
                                    "estado": "error",
                                    "msg": "error al guardar",
                                    "err": error
                                })
                            });
                        });
                    }
                    else {
                        sql = "SELECT * FROM shippers";
                        conn.query(sql, function(err, result) {
                            conn.end(function() {
                                callback(null, {
                                    statusCode: 200,
                                    body: JSON.stringify({
                                        "estado": "ok",
                                        "lista": result
                                    })
                                });
                            });
                        });
                    }
                });
            }
        });
    }

};