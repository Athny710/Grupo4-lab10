const mysql = require('mysql2');
const querystring = require('querystring');

exports.handler = function(event, context, callback) {

    if (event.body !== null && event.body !== undefined) {

        var bodyBase64 = Buffer.from(event.body, 'base64').toString();
        var body = querystring.parse(bodyBase64);

        var token = body.token;
        var description = body.description;
        var conn = mysql.createConnection({
            host: "localhost",
            user: "root",
            password: "root",
            port: 3306,
            database: "teletok_lambda"
        });

        conn.connect(function(error) {
            if (error) {
                conn.end(function() {
                    callback(error, {
                        statusCode: 400,
                        body: JSON.stringify({
                            "estado": "error",
                            "msg": "error en la conexión a base de datos"
                        })
                    });
                });
            }
            else {

                var sql = "SELECT * FROM teletok_lambda.token where code= ";
                var parametros = [token];
                conn.query(query, parametros, function (err, resultado) {
                    if (err) {
                        console.log(err);
                    } else {
                        response.json(resultado);
                    }
                });
            }
        });
    }

};
