const mysql = require('mysql2');

exports.handler = (event, context, callback) => {
    
    var conn = mysql.createConnection({
        host: "database-lab10.ci5ys4ttduae.us-east-1.rds.amazonaws.com",
        user: "admin",
        password: "hEDSOa0YQEnSvLlNP019",
        port: 3306,
        database: "northwind"
    });

    conn.connect(function(error){
        if(error){
            conn.end(function(){
                callback(error, {
                    statusCode: 400,
                    body: JSON.stringify({
                        "estado": "error",
                        "msg": error
                    }),
                });
            });
        }else{
            conn.query("select * from Products", function(err, result){
                if(err){
                    conn.end(function(){
                        callback(error, {
                            statusCode: 400,
                            body: JSON.stringify({
                                "estado": "error2",
                                "msg": error
                            }),
                        });
                    });
                }else{
                    conn.end(function(){
                        callback(null, {
                            statusCode: 200,
                            headers: {
                              'Content-Type': 'Application/json'  
                            },
                            body: JSON.stringify({
                                "estado": "ok",
                                "lista": result
                            })
                        });
                    });
                }
            });
            
        }
    });
};
